Pack de sprites 3D detoures haute precision (PNG RGBA transparent) - Personnage Femme Blonde
Total : 48 sprites individuels detoures proprement sur fond transparent.

Dossiers inclus :
- 01_degout_progressif/ : 8 etapes intermediaires (neutre -> degout marque)
- 02_degout_intense_nausee/ : 10 etapes avancees (repulsion intense, haut-le-coeur, recul)
- 03_mastication_cycle/ : 10 etapes du cycle complet de mastication et deglutition
- 04_sourire_vers_rire/ : 10 etapes progressives du sourire au rire franc
- 05_danse_rythme/ : 10 etapes dynamiques de danse et groove
- manifest.json : index complet des frames, chemins et dimensions pour import moteur/application
